# ParhoPakistan — free website starter

## What's included
- Responsive homepage for mobile and desktop
- Class 9, 10, 11 and 12 sections
- Search and filters for resource type and Punjab board
- Resource categories: past papers, pairing schemes, guess papers, notes and MCQs
- Basic SEO title, description and keywords

## Important before publishing
This is a starter template, not a completed archive of real PDFs. Add verified papers and schemes before advertising them as downloadable. Do not upload copyrighted books/scans or pirated material without permission. Write original notes and clearly label practice/guess papers as unofficial.

## Free publishing with GitHub Pages
1. Create a GitHub account.
2. Create a public repository named `parhopakistan`.
3. Upload `index.html` to the repository root.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select `main` and `/root`, then Save.
6. GitHub will show your free website address after deployment.

You can also use Blogger for a no-code blog, but this HTML template is designed for static hosting.

## How to add a real download
In `index.html`, find the `resources` array near the bottom. Add a resource with fields:
`{title:"Class 9 Biology 2025 Past Paper", cls:"9", type:"Past Paper", board:"Faisalabad", desc:"BISE Faisalabad annual paper."}`
For a real PDF, upload the PDF to a permitted file host and change the resource card rendering to include its verified URL. Do not invent download links.

## Monetization
Google AdSense approval is not guaranteed. Publish useful original content, provide About/Contact/Privacy Policy pages, follow AdSense policies, and wait for real search traffic. AdSense account holders must be 18+; a parent/guardian can apply and receive payments on their own account.
