PARHOPAKISTAN V2 — UPLOAD GUIDE

Included:
- index.html: the complete updated website (single-file static site).
- The page includes English/Urdu text toggle, class 9–12, Pakistan board directory, subject/resource filters, and search.
- Resource cards are intentionally marked "File not added yet". No fake or unverified past papers are included.

HOW TO UPDATE YOUR LIVE GITHUB PAGES WEBSITE:
1. Open https://github.com/jin999-alt/parhopakistan
2. Click Add file > Upload files.
3. Upload this new index.html and choose Commit changes.
4. If GitHub asks whether to replace the existing index.html, confirm the replacement.
5. Wait a few minutes, then refresh https://jin999-alt.github.io/parhopakistan/

IMPORTANT:
- Upload index.html to the repository root (main page), not inside another folder.
- Keep your existing repository and GitHub Pages settings.
- To add real study files later, upload permitted PDFs into folders such as papers/class-9/ and add links to them in the page.
- Only publish material you created, have permission to share, or that the relevant board has made available for redistribution. Link to official board pages for official notices.
- Replace add-your-email@example.com with a contact email before applying for ads.
- Google AdSense approval and earnings are not guaranteed. Build useful original content, clear About/Contact/Privacy/Disclaimer pages, and follow current AdSense policies.
